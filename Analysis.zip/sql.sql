--
-- Database: `elibrary`
-- Created By: Eng.EmranCo
--
CREATE DATABASE IF NOT EXISTS `elibrary`;
USE `elibrary`;

-- --------------------------------------------------------
-- Tables structure 


CREATE TABLE `author` (
  `id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `email` varchar(50) NOT NULL,
  `info` varchar(200) NOT NULL
);

-- --------------------------------------------------------


CREATE TABLE `book` (
  `id` int(11) NOT NULL,
  `cat_id` int(11) NOT NULL,
  `pub_id` int(11) NOT NULL,
  `offers_id` int(11),
  `title` varchar(50) NOT NULL,
  `pub_date` datetime NOT NULL,
  `auth_date` datetime NOT NULL,
  `edition` varchar(15) NOT NULL,
  `price` decimal(10,3) NOT NULL,
  `language` varchar(10) NOT NULL
);

-- --------------------------------------------------------

CREATE TABLE `book_authors` (
  `id` int(11) NOT NULL,
  `book_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `auth_prec` decimal(10,0) NOT NULL DEFAULT 0
);

-- --------------------------------------------------------

CREATE TABLE `book_details` (
  `id` int(11) NOT NULL,
  `book_id` int(11) NOT NULL,
  `url` varchar(200) NOT NULL,
  `nopages` int(11) NOT NULL,
  `weight` decimal(10,0) NOT NULL,
  `format` varchar(10) NOT NULL,
  `dimension` varchar(15) NOT NULL,
  `size` decimal(10,0) NOT NULL,
  `description` varchar(200) DEFAULT NULL
);

-- --------------------------------------------------------

CREATE TABLE `book_images` (
  `id` int(11) NOT NULL,
  `book_id` int(11) NOT NULL,
  `image` varchar(300) NOT NULL
);

-- --------------------------------------------------------

CREATE TABLE `book_orders` (
  `id` int(11) NOT NULL,
  `book_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` decimal(10,0) NOT NULL
);

-- --------------------------------------------------------

CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `book_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `price` decimal(10,0) NOT NULL,
  `quantity` int(11) NOT NULL
);

-- --------------------------------------------------------

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `image` VARCHAR(200) NULL DEFAULT NULL,
  `description` varchar(100) DEFAULT NULL,
  `super_Category` int(11),
);

-- --------------------------------------------------------

CREATE TABLE `delivery_history` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `destination` varchar(100) NOT NULL,
  `price` decimal(10,0) NOT NULL,
  `planned_time` datetime NOT NULL,
  `actual_time` datetime NOT NULL DEFAULT current_timestamp(),
  `status` tinyint(4) NOT NULL DEFAULT 0
);

-- --------------------------------------------------------

CREATE TABLE `favorits` (
  `id` int(11) NOT NULL,
  `book_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL
);

-- --------------------------------------------------------

CREATE TABLE `offers` (
  `id` int(11) NOT NULL,
  `discount` decimal(10,0) NOT NULL,
  `deadline` date NOT NULL
);

-- --------------------------------------------------------

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `payment_id` int(11) NOT NULL,
  `time` datetime NOT NULL,
  `total_price` decimal(10,0) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 0
);

-- --------------------------------------------------------

CREATE TABLE `payment` (
  `id` int(11) NOT NULL,
  `card_no` int(11) NOT NULL,
  `card_name` varchar(30) NOT NULL,
  `expir_date` date NOT NULL,
  `zip_code` int(10) NOT NULL,
  `cvv` int(10) NOT NULL,
  `full_name` varchar(60) NOT NULL
);

-- --------------------------------------------------------

CREATE TABLE `permission` (
  `id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `description` varchar(200) DEFAULT NULL
);

-- --------------------------------------------------------

CREATE TABLE `publisher` (
  `id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `info` varchar(200) NOT NULL
);

-- --------------------------------------------------------

CREATE TABLE `reviews` (
  `id` int(11) NOT NULL,
  `book_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `rate` int(1) NOT NULL,
  `comment` varchar(500) DEFAULT NULL
);

-- --------------------------------------------------------

CREATE TABLE `role` (
  `id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL
);

-- --------------------------------------------------------

CREATE TABLE `role_permissions` (
  `id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  `applied_time` datetime NOT NULL DEFAULT current_timestamp()
);

-- --------------------------------------------------------

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  `full_name` varchar(50) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `gender` tinyint(4) NOT NULL DEFAULT 1,
  `email` varchar(50) NOT NULL,
  `bio` varchar(50) NOT NULL
);


-- #################################################################

-- Indexes for tables 
--
ALTER TABLE `author`
  ADD PRIMARY KEY (`id`);

--

ALTER TABLE `book`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cat_id` (`cat_id`),
  ADD KEY `offers_id` (`offers_id`),
  ADD KEY `pub_id` (`pub_id`);

--

ALTER TABLE `book_authors`
  ADD PRIMARY KEY (`id`),
  ADD KEY `author_id` (`author_id`),
  ADD KEY `book_id` (`book_id`);

--

ALTER TABLE `book_details`
  ADD PRIMARY KEY (`id`),
  ADD KEY `book_id` (`book_id`);

--

ALTER TABLE `book_images`
  ADD PRIMARY KEY (`id`),
  ADD KEY `book_id` (`book_id`);

--

ALTER TABLE `book_orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `book_id` (`book_id`),
  ADD KEY `order_id` (`order_id`);

--

ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`),
  ADD KEY `book_id` (`book_id`),
  ADD KEY `user_id` (`user_id`);

--

ALTER TABLE `category`
  ADD PRIMARY KEY (`id`),
  ADD KEY `super_Category` (`super_Category`);

--

ALTER TABLE `delivery_history`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_id` (`order_id`);

--

ALTER TABLE `favorits`
  ADD PRIMARY KEY (`id`),
  ADD KEY `book_id` (`book_id`),
  ADD KEY `user_id` (`user_id`);

--

ALTER TABLE `offers`
  ADD PRIMARY KEY (`id`);

--

ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `payment_id` (`payment_id`),
  ADD KEY `user_id` (`user_id`);

--

ALTER TABLE `payment`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `card_no` (`card_no`);

--

ALTER TABLE `permission`
  ADD PRIMARY KEY (`id`);

--

ALTER TABLE `publisher`
  ADD PRIMARY KEY (`id`);

--

ALTER TABLE `reviews`
  ADD PRIMARY KEY (`id`),
  ADD KEY `book_id` (`book_id`),
  ADD KEY `user_id` (`user_id`);

--

ALTER TABLE `role`
  ADD PRIMARY KEY (`id`);

--

ALTER TABLE `role_permissions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `permission_id` (`permission_id`),
  ADD KEY `role_id` (`role_id`);

--

ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD KEY `role_id` (`role_id`);


-- #################################################################
-- AUTO_INCREMENT for tables 

ALTER TABLE `author`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--

ALTER TABLE `book`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--

ALTER TABLE `book_authors`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--

ALTER TABLE `book_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--

ALTER TABLE `book_images`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--

ALTER TABLE `book_orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--

ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--

ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--

ALTER TABLE `delivery_history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--

ALTER TABLE `favorits`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--

ALTER TABLE `offers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--

ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--

ALTER TABLE `payment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--

ALTER TABLE `permission`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--

ALTER TABLE `publisher`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--

ALTER TABLE `reviews`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--

ALTER TABLE `role`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--

ALTER TABLE `role_permissions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--

ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;


-- #################################################################
-- Constraints for tables 

ALTER TABLE `book`
  ADD CONSTRAINT `book_ibfk_1` FOREIGN KEY (`cat_id`) REFERENCES `category` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `book_ibfk_2` FOREIGN KEY (`offers_id`) REFERENCES `offers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `book_ibfk_3` FOREIGN KEY (`pub_id`) REFERENCES `publisher` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--

ALTER TABLE `book_authors`
  ADD CONSTRAINT `book_authors_ibfk_1` FOREIGN KEY (`author_id`) REFERENCES `author` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `book_authors_ibfk_2` FOREIGN KEY (`book_id`) REFERENCES `book` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--

ALTER TABLE `book_details`
  ADD CONSTRAINT `book_details_ibfk_1` FOREIGN KEY (`book_id`) REFERENCES `book` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--

ALTER TABLE `book_images`
  ADD CONSTRAINT `book_images_ibfk_1` FOREIGN KEY (`book_id`) REFERENCES `book` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--

ALTER TABLE `book_orders`
  ADD CONSTRAINT `book_orders_ibfk_1` FOREIGN KEY (`book_id`) REFERENCES `book` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `book_orders_ibfk_2` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--

ALTER TABLE `cart`
  ADD CONSTRAINT `cart_ibfk_1` FOREIGN KEY (`book_id`) REFERENCES `book` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `cart_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--

ALTER TABLE `category`
  ADD CONSTRAINT `category_ibfk_1` FOREIGN KEY (`super_Category`) REFERENCES `category` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--

ALTER TABLE `delivery_history`
  ADD CONSTRAINT `delivery_history_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--

ALTER TABLE `favorits`
  ADD CONSTRAINT `favorits_ibfk_1` FOREIGN KEY (`book_id`) REFERENCES `book` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `favorits_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--

ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`payment_id`) REFERENCES `payment` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `orders_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--

ALTER TABLE `reviews`
  ADD CONSTRAINT `reviews_ibfk_1` FOREIGN KEY (`book_id`) REFERENCES `book` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `reviews_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--

ALTER TABLE `role_permissions`
  ADD CONSTRAINT `role_permissions_ibfk_1` FOREIGN KEY (`permission_id`) REFERENCES `permission` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `role_permissions_ibfk_2` FOREIGN KEY (`role_id`) REFERENCES `role` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--

ALTER TABLE `user`
  ADD CONSTRAINT `user_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `role` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;




-- #################################################################
-- Select Queries way 1

-- Login check only
SELECT `full_name`, `email`, `bio`
FROM `user`
WHERE
    (  `username` = 'EmranCo' OR `email` = 'alhaddademran@gmail.com' ) 
    AND `password` = 'EmranCo';

-- Register
INSERT INTO `user`(`role_id`, `full_name`, `username`, `password`, `gender`, `email`, `bio`) 
VALUES ('[value-2]','[value-3]','[value-4]','[value-5]','[value-6]','[value-7]','[value-8]')

-- Number of Card Items
SELECT COUNT(`cart`.`user_id`) AS `noItems`
FROM `cart` WHERE `cart`.`user_id`=1;

-- Categories
SELECT `category`.`name`, `category`.`image`
FROM `category`;

-- Offers
SELECT `book_images`.`image`, `book`.`title`, `reviews`.`rate`, `book_details`.`format`, `book`.`price`, `offers`.`discount`, `offers`.`deadline`
FROM `offers`
LEFT JOIN `book` ON `offers`.`id` = `book`.`offers_id` 
LEFT JOIN `book_details` ON `book`.`id` = `book_details`.`book_id` 
LEFT JOIN `book_images` ON `book`.`id` = `book_images`.`book_id` 
LEFT JOIN `cart` ON `book`.`id` = `cart`.`book_id` 
LEFT JOIN `reviews` ON `book`.`id` = `reviews`.`book_id` 

-- Books with categories
SELECT
    `book_images`.`image`,
    `book`.`title`,
    `book`.`price`,
    `book_details`.`format`,
    `reviews`.`rate`,
    `category`.`name`
FROM
    `category`
LEFT JOIN `book` ON `category`.`id` = `book`.`cat_id`
LEFT JOIN `book_details` ON `book`.`id` = `book_details`.`book_id`
LEFT JOIN `book_images` ON `book`.`id` = `book_images`.`book_id`
LEFT JOIN `cart` ON `book`.`id` = `cart`.`book_id`
LEFT JOIN `reviews` ON `book`.`id` = `reviews`.`book_id`;

-- Reviews
SELECT `user`.`full_name` AS `User`, `book`.`title` AS `Book`, `reviews`.`comment` AS `Review`
FROM `book`
     JOIN `reviews` ON `reviews`.`book_id` = `book`.`id`
     JOIN `user` ON `reviews`.`user_id` = `user`.`id`
ORDER BY `user`.`full_name` ASC

----------------------------------------------------------
-- Select Queries way 2 ^ | ^

-- Select for table `category`

SELECT * FROM `category`;

-- Select for table `book`

SELECT `category`.`name` AS Category,
`title`, `pub_date`, `auth_date`,
`publisher`.`name` AS publisher_name,  
`edition`, `price`, `language` 
FROM `book`
INNER JOIN `category` ON `category`.`id` = `book`.`cat_id` 
INNER JOIN `publisher` ON `publisher`.`id` = `book`.`pub_id`;


-- Select for table `offers`

SELECT `category`.`name` AS Category, 
`offers`.`discount` AS dicount_percent, 
`title`, `pub_date`, `auth_date`,
`publisher`.`name` AS publisher_name,  
`edition`, `price`, `language`
FROM `book`
INNER JOIN `category` ON `category`.`id` = `book`.`cat_id` 
INNER JOIN `publisher` ON `publisher`.`id` = `book`.`pub_id` 
INNER JOIN `offers` ON `offers`.`id` = `book`.`offers_id`;

--
-- Select for table `bookDetails`
--
SELECT `category`.`name` AS Category,
`title`, `pub_date`, `auth_date`,
`publisher`.`name` AS publisher_name,  
`edition`, `price`, `language`, `book_details`.`url`, `book_details`.`nopages`, `book_details`.`weight`, `book_details`.`format`, `book_details`.`dimension`, `book_details`.`size`, `book_details`.`description` 
FROM `book` 
INNER JOIN `book_details` ON `book_details`.`book_id` = `book`.id 
INNER JOIN `category` ON `category`.`id` = `book`.`cat_id` 
INNER JOIN `publisher` ON `publisher`.`id` = `book`.`pub_id`;

--
-- Select for table `reviews`
--
SELECT `user`.`full_name`, `book`.`title` AS book_title, `reviews`.`comment`, `reviews`.`rate` 
FROM `reviews` 
INNER JOIN `book` ON `reviews`.`book_id` = `book`.`id` 
INNER JOIN `user` ON `reviews`.`user_id` = `user`.`id`;


--
-- Add to `cart`
--
INSERT INTO `cart`(`id`, `book_id`, `user_id`, `price`, `quantity`) 
VALUES (NULL,1,2,3500,4),
	     (NULL,1,1,2200,4);


